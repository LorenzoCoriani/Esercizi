import java.util.*;
import java.io.*;
class Main{
	public static void main(String[] args){
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader key = new BufferedReader(in);
		try{
			Vector<Segmento> v = new Vector<Segmento>();
			double ax,ay,bx,by;
			int risposta;
			String tmp;
			int indice;
			boolean segmentoTrovato = false;
			Punto p= new Punto();
			Punto p2= new Punto();
			Segmento s = new Segmento();
			do{
				System.out.println("Scegli un'opzione: ");
				System.out.println("1:Inserisci un segmento  ");
				System.out.println("2: Visualizza un segmento ");
				System.out.println("3: Elimina un segmento ");
				System.out.println("4:Trovare un segmento ");
				System.out.println("5: Esci");

				risposta = Integer.parseInt(key.readLine());
				
				
				switch (risposta){
				    case 1: {
					System.out.println("Inserisci ax del  punto:");
					ax=Double.parseDouble(key.readLine());
					System.out.println("Inserisci ay del  punto:");
					ay=Double.parseDouble(key.readLine());
					System.out.println("Inserisci bx del  punto:");
					bx=Double.parseDouble(key.readLine());
					System.out.println("Inserisci by del  punto:");
					by=Double.parseDouble(key.readLine());

					

					
					s.p.x=ax;
					s.p.y=ay;
					s.p2.x=bx;
					s.p2.y=by;
					
					v.add(s);
					
					break;
				    }
				    case 2:{
					System.out.println("Il segmento e: "+ v.toString());
					
					break;
				    }
				    case 3:{
					v.remove(s);
					break;
					}
				    case 4:{
					
					System.out.println("Inserisci ax del  punto:");
					ax=Double.parseDouble(key.readLine());
					System.out.println("Inserisci ay del  punto:");
					ay=Double.parseDouble(key.readLine());
					System.out.println("Inserisci bx del  punto:");
					bx=Double.parseDouble(key.readLine());
					System.out.println("Inserisci by del  punto:");
					by=Double.parseDouble(key.readLine());
					
					Segmento strova = new Segmento();
					s.p.x=ax;
					s.p.y=ay;
					s.p2.x=bx;
					s.p2.y=by;
					
					
					segmentoTrovato = v.contains(strova);

					if (segmentoTrovato) {
						System.out.println("Il segmento e  presente nella lista.");
					} else {
						System.out.println("Il segmento e non presente nella lista.");
					}    
					break;   
					}
				    case 5:{
					
					break;
				    }
				    default:{
					System.out.println("Opzione non valida!");
					break;
				    }
				    
			}
			}while(risposta!=5);
		}catch (IOException e){
			System.out.println("errore");
		}
	}
}